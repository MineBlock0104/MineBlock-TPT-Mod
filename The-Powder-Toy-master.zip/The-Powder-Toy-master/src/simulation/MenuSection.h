#ifndef MENUSECTION_H_
#define MENUSECTION_H_

struct menu_section
{
	const char *icon;
	const char *name;
	int itemcount;
	int doshow;
};

#endif
