#include "../LuaCompat.h"
void luaopen_socket(lua_State *l);
